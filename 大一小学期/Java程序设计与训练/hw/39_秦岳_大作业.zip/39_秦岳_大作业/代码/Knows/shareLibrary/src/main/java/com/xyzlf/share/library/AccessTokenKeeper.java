///*
// * Copyright (C) 2010-2013 The SINA WEIBO Open Source Project
// *
// * Licensed under the Apache License, Version 2.0 (the "License");
// * you may not use this file except in compliance with the License.
// * You may obtain a copy of the License at
// *
// *      http://www.apache.org/licenses/LICENSE-2.0
// *
// * Unless required by applicable law or agreed to in writing, software
// * distributed under the License is distributed on an "AS IS" BASIS,
// * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// * See the License for the specific language governing permissions and
// * limitations under the License.
// */
//
//package com.xyzlf.share.library;
//
//import android.content.Context;
//import android.content.SharedPreferences;
//import android.content.SharedPreferences.Editor;
//import android.os.Build;
//
//import com.sina.weibo.sdk.auth.Oauth2AccessToken;
//
//public class AccessTokenKeeper {
//    private static final String PREFERENCES_NAME = "com_weibo_sdk_android";
//
//    private static final String KEY_UID           = "uid";
//    private static final String KEY_ACCESS_TOKEN  = "access_token";
//    private static final String KEY_EXPIRES_IN    = "expires_in";
//    private static final String KEY_REFRESH_TOKEN    = "refresh_token";
//
//    public static void writeAccessToken(Context context, Oauth2AccessToken token) {
//        if (null == context || null == token) {
//            return;
//        }
//        SharedPreferences pref = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_APPEND);
//        Editor editor = pref.edit();
//        editor.putString(KEY_UID, token.getUid());
//        editor.putString(KEY_ACCESS_TOKEN, token.getToken());
//        editor.putString(KEY_REFRESH_TOKEN, token.getRefreshToken());
//        editor.putLong(KEY_EXPIRES_IN, token.getExpiresTime());
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
//            editor.apply();
//        } else {
//            editor.commit();
//        }
//    }
//
//    public static Oauth2AccessToken readAccessToken(Context context) {
//        if (null == context) {
//            return null;
//        }
//        Oauth2AccessToken token = new Oauth2AccessToken();
//        SharedPreferences pref = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_APPEND);
//        token.setUid(pref.getString(KEY_UID, ""));
//        token.setToken(pref.getString(KEY_ACCESS_TOKEN, ""));
//        token.setRefreshToken(pref.getString(KEY_REFRESH_TOKEN, ""));
//        token.setExpiresTime(pref.getLong(KEY_EXPIRES_IN, 0));
//
//        return token;
//    }
//
//    public static void clear(Context context) {
//        if (null == context) {
//            return;
//        }
//        SharedPreferences pref = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_APPEND);
//        Editor editor = pref.edit();
//        editor.clear();
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
//            editor.apply();
//        } else {
//            editor.commit();
//        }
//    }
//}
