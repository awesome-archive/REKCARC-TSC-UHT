/* Quartus Prime Version 19.1.0 Build 670 09/22/2019 SJ Lite Edition */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(EPM240T100) Path("D:/digital_experiment/lock/output_files/") File("lock.pof") MfrSpec(OpMask(1) SEC_Device(EPM240T100) Child_OpMask(2 1 1));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
