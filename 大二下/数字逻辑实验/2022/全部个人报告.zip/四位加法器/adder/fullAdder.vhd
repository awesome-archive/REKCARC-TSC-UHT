library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity fullAdder is
	port(
		a,b,cin:in std_logic;
		f,cout:out std_logic;
		p,g:buffer std_logic
	);
end fullAdder;

architecture plus of fullAdder is
	component halfAdder
		port(
			a,b:in std_logic;
			f,cout:out std_logic
		);
	end component;
	signal r:std_logic;
begin
	half1:halfAdder port map(a,b,p,g);
	half2:halfAdder port map(p,cin,f,r);
	cout<=r or g;
end plus;