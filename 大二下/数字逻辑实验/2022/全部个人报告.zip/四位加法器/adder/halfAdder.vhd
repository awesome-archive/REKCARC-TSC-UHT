library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity halfAdder is
	port(
		a,b:in std_logic;
		f,cout:out std_logic
	);
end halfAdder;

architecture plus of halfAdder is
begin
	process(a,b)
	begin
		f<=a xor b;
		cout<=a and b;
	end process;
end plus;
