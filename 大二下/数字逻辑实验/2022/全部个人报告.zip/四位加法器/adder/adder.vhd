library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity adder is
	port( 
		a,b:in std_logic_vector(3 downto 0);--输入为 a,b 两个四位二进制数
		c0:in std_logic;--也即 C_{-1}
		f:out std_logic_vector(3 downto 0);--输出为一个四位二进制数
		c4:out std_logic --表示向更高位进位
	);
end adder;

architecture advance of adder is
	component fullAdder
		port(
			a,b,cin:in std_logic;
			f,cout:out std_logic;
			p,g:buffer std_logic
		);
	end component;
	signal p,g:std_logic_vector(3 downto 0);
	signal c:std_logic_vector(2 downto 0);
begin --参考数电讲义，使用四个全加器实现超前进位四位加法器
	f0:fullAdder port map(a(0),b(0),c0,f=>f(0),p=>p(0),g=>g(0));
	f1:fullAdder port map(a(1),b(1),c(0),f=>f(1),p=>p(1),g=>g(1));
	f2:fullAdder port map(a(2),b(2),c(1),f=>f(2),p=>p(2),g=>g(2));
	f3:fullAdder port map(a(3),b(3),c(2),f=>f(3),p=>p(3),g=>g(3));	
	process(p,g,c0)
	begin --超前进位加法器的逻辑表达式
		c(0)<=g(0) or (p(0) and c0);
		c(1)<=g(1) or (p(1) and g(0)) or (p(1) and p(0) and c0);
		c(2)<=g(2) or (p(2) and g(1)) or (p(2) and p(1) and g(0)) or (p(2) and p(1) and p(0) and c0);
		c4<=g(3) or (p(3) and g(2)) or (p(3) and p(2) and g(1)) or (p(3) and p(2) and p(1) and g(0)) or (p(3) and p(2) and p(1) and p(0) and c0);
	end process;
end advance;