library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity bite is
	port(
		a,b:in std_logic_vector(3 downto 0);--输入为a,b两个四位二进制数
		c0:in std_logic;--低位进位输入
		f:out std_logic_vector(3 downto 0);--输出为一个四位二进制数
		c4:out std_logic --向更高位的进位输出
	);
end bite;

architecture advance of bite is
	component fullAdder
		port(
			a,b,cin:in std_logic;
			f,cout:out std_logic
		);
	end component;
	signal c:std_logic_vector(2 downto 0);
	begin--元件例化，用四个全加器实现四位加法器，没有复杂的逻辑
	f0:fullAdder port map(a(0),b(0),c0,f(0),c(0));
	f1:fullAdder port map(a(1),b(1),c(0),f(1),c(1));
	f2:fullAdder port map(a(2),b(2),c(1),f(2),c(2));
	f3:fullAdder port map(a(3),b(3),c(2),f(3),c4);
end advance;
