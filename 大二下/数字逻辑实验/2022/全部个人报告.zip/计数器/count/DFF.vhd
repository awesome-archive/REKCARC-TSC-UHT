library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity myDFF is
	 port(
		  D, CP, Rd, Sd: in std_logic ;
		  Q: out std_logic :='0';
		  nQ: out std_logic :='1'
	 );
end myDFF;

architecture arch of myDFF is
begin
	 process(Rd, Sd, CP)
		 begin
		 if (Rd = '0') then
			  Q <= '0';
			  nQ <= '1';
		 elsif (Sd = '0') then
			  Q <= '1';
			  nQ <= '0';
		 elsif (CP'event and CP = '1') then
			  Q <= D;
			  nQ <= not D;
		 end if ;
	 end process ;
end arch;
