library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity count is
	 port(
		 clk , rst , pause: in std_logic ;
		 lout , hout: out std_logic_vector(6 downto 0)
	 );
end count;

architecture count_bhv of count is
	 component clock
		 port(
			 clk , rst : in std_logic ;
			 lout , hout: out std_logic_vector(6 downto 0)
		 );
	 end component;
	 signal clk2 : std_logic := '0';
	 signal t: integer := 0;
begin
	 main_count: clock port map(clk2, rst , lout , hout);
	 process(pause, clk , rst )
		 begin
		 if ( rst = '1') then
			 t <= 0;
			 clk2 <= '0';
		 elsif (clk 'event and clk = '1' and pause = '0') then
			 if (t = 1000000) then
				 t <= 0;
				 clk2 <= '1';
			 elsif (t = 500000) then
				 t <= t + 1;
				 clk2 <= '0';
			 else
				 t <= t + 1;
			 end if ;
		 end if ;
	 end process ;
end count_bhv;
