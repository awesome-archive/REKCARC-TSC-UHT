library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity clock is
	 port(
		 clk , rst : in std_logic ;
		 lout , hout: out std_logic_vector
		 );
	 end clock;

architecture clock_bhv of clock is
	 component clock_60
		 port(
			 clk , rst : in std_logic ;
			 low, high: out std_logic_vector(3 downto 0)
		 );
	 end component;
	 component digit_7
		 port(
			 number: in std_logic_vector(3 downto 0);
			 display: out std_logic_vector(6 downto 0)
		 );
	 end component;
	 signal low, high: std_logic_vector(3 downto 0);
begin
	 count: clock_60 port map(clk, rst, low, high);
	 digit_low: digit_7 port map(low, lout);
	 digit_high: digit_7 port map(high, hout);
end clock_bhv;