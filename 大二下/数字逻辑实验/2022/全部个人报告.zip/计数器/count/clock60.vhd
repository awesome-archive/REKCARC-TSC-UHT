library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity clock_60 is
	 port(
		 clk , rst : in std_logic ;
		 low, high: out std_logic_vector(3 downto 0)
	 );
end clock_60;

architecture clock_60_bhv of clock_60 is
	 component myDFF
		 port(
			 D, CP, Rd, Sd: in std_logic ;
			 Q: out std_logic := '0';
			 nQ: out std_logic := '1'
		 );
	 end component;
	 
	 component clock_6
		 port(
			 clk , Rd, c0: in std_logic ;
			 out_6: out std_logic_vector(3 downto 0)
		 );
	 end component;
	 
	 component clock_10
		 port(
		 clk , Rd: in std_logic ;
		 out_10: out std_logic_vector(3 downto 0)
		 );
	 end component;
	 
	 signal D, c0, Rd: std_logic ;
	 signal QL, QH: std_logic_vector(3 downto 0);
begin
	 count_low: clock_10 port map(clk, Rd, QL);
	 count_high: clock_6 port map(clk, Rd, c0, QH);
	 trriger: myDFF port map(D, clk, Rd, '1', c0);
	 Rd <= not rst;
	 D <= (QL(3) and (not QL(2))) and ((not QL(1)) and (not QL(0)));
	 low <= QL;
	 high <= QH;
end clock_60_bhv;