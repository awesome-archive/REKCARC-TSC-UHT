library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity clock_6 is
	 port(
		 clk, Rd, c0: in std_logic ;
		 out_6: out std_logic_vector(3 downto 0)
	 );
end clock_6;

architecture clock_6_bhv of clock_6 is
  component myDFF is
	 port(
	 D, CP, Rd, Sd: in std_logic ;
	 Q: out std_logic := '0';
	 nQ: out std_logic := '1'
	 );
  end component;
  signal D, Q, nQ: std_logic_vector(2 downto 0);
begin
	 lb0: for i in 0 to 2 generate
		Di: myDFF port map(D(i), clk , Rd, '1', Q(i), nQ(i));
	 end generate lb0;
	 D(0) <= c0 xor Q(0);
	 D(1) <= ((not c0) and Q(1)) or (c0 and (nQ(2) and (Q(1) xor Q(0))));
	 D(2) <= ((not c0) and Q(2)) or (c0 and ((Q(2) and nQ(0)) or (Q(1) and Q(0))));
	 out_6(2 downto 0) <= Q;
	 out_6(3) <= '0';
end clock_6_bhv;
